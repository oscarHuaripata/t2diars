﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinancistoCloneWeb.Models
{
    public class UsuarioPokemon
    {
        public UsuarioPokemon()
        {
            Captura = DateTime.Now;
        }
        public int Id { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
        public int     PokemonId { get; set; }
        public Pokemon Pokemon { get; set; }
        public DateTime Captura { get; set; }
    }
}
