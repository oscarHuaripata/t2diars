﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FinancistoCloneWeb.Models
{
    public class Pokemon
    {
        public int         Id { get; set; }
        [Required(ErrorMessage = "El campo nombre es requerido")]
        public string      Nombre { get; set; }
        public string      ImagePath { get; set; }
        public int         UserId { get; set; }

        // relaciones
        [Required(ErrorMessage = "El campo tipo es requerido")]
        public int         PokemonTypeId { get; set; }
        public PokemonType PokemonType { get; set; }
    }
}
