﻿using FinancistoCloneWeb.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FinancistoCloneWeb.Controllers
{
    [Authorize]
    public class PokemonController : BaseController
    {
        private FinancistoContext _context;
        public IHostEnvironment _hostEnv;

        public PokemonController(FinancistoContext context, IHostEnvironment hostEnv):base(context)
        {
            _context = context;
            _hostEnv = hostEnv;
        }

        [HttpGet]
        public ActionResult Index(string buscar)
        {
            var pokemon = new Pokemon();
            var pokemons = _context.Pokemons
            //.Where(o => o.UserId == LoggedUser().Id)
            .Include(o => o.PokemonType)
            .ToList();
            if (!string.IsNullOrEmpty(buscar))
            {
                pokemons = _context.Pokemons.Where(c => c.Nombre.ToUpper().Contains(buscar))
                .Include(o => o.PokemonType)
                .ToList();
            }

            return View(pokemons);            
        }

        [HttpPost]
        public ActionResult buscar(string Buscar)
        {
            return RedirectToAction("Index", new { buscar = Buscar });
        }

        [HttpGet]
        public ActionResult atrapar(int id)
        {
            _context.UsuarioPokemons.Add(new UsuarioPokemon { PokemonId=id, UserId = LoggedUser().Id });
            _context.SaveChanges();
            return RedirectToAction("Atrapados");
        }


        [HttpGet]
        public ActionResult liberar(int id)
        {
            var findob = _context.UsuarioPokemons.FirstOrDefault(c => c.Id == id);
            
            _context.UsuarioPokemons.Remove(findob);
            _context.SaveChanges();
            return RedirectToAction("Atrapados");
        }


        [HttpGet]
        public ActionResult Atrapados()
        {
            var pokemon = new UsuarioPokemon();
            var pokemons = _context.UsuarioPokemons.Include(c=>c.Pokemon).Include(c=>c.Pokemon.PokemonType)
                .Include(c => c.User)
            .Where(o => o.UserId == LoggedUser().Id)
            .ToList();
           
            return View(pokemons);
        }


        [HttpGet]
        public ActionResult Create() // GET
        {
            ViewBag.Types = _context.PokemonTypes.ToList();
            return View("Create", new Pokemon());
        }

        [HttpPost]
        public ActionResult Create(Pokemon pokemon, IFormFile image) // POST
        {
            //account.UserId = LoggedUser().Id;

            if (ModelState.IsValid)
            {
                pokemon.ImagePath = SaveImage(image);


                _context.Pokemons.Add(pokemon);
                _context.SaveChanges();

                return RedirectToAction("Index");
            }
            ViewBag.Types = _context.Types.ToList();
            return View("Create", pokemon);
        }



        //[HttpGet]
        //public ActionResult Edit(int id)
        //{
        //    ViewBag.Types = _context.Types.ToList();
        //    var account = _context.Accounts.Where(o => o.Id == id).FirstOrDefault(); // si no lo encutra retorna un null

        //    return View(account);
        //}

        //[HttpPost]
        //public ActionResult Edit(Account account)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Accounts.Update(account);
        //        _context.SaveChanges();
        //        return RedirectToAction("Index"); 
        //    }

        //    ViewBag.Types = _context.Types.ToList();            
        //    return View(account);
        //}

        //[HttpGet]
        //public ActionResult Delete(int id)
        //{
        //    var account = _context.Accounts.Where(o => o.Id == id).FirstOrDefault();
        //    _context.Accounts.Remove(account);
        //    _context.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        private string SaveImage(IFormFile image)
        {
            if (image != null && image.Length > 0)
            {
                var basePath = _hostEnv.ContentRootPath + @"\wwwroot";
                var ruta = @"\files\" + image.FileName;

                using (var strem = new FileStream(basePath + ruta, FileMode.Create))
                {
                    image.CopyTo(strem);
                    return ruta;
                }
            }
            return null;
        }

    }
}
