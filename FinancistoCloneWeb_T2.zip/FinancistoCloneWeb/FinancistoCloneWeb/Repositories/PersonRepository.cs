﻿using FinancistoCloneWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinancistoCloneWeb.Repositories
{
    public interface IPersonRepository
    {
        public List<Person> GetAll();
        public bool Build();
    }

    public class PersonRepository : IPersonRepository
    {
        private readonly FinancistoContext context;

        public PersonRepository(FinancistoContext context)
        {
            this.context = context;
        }

        public List<Person> GetAll()
        {
            return context.People.ToList();
        }

        public bool Build()
        {
            if (!context.PokemonTypes.Any())
            {
                List<PokemonType> TypePokemon = new List<PokemonType>
                {
                    new PokemonType { Name = "ELECTRICO"},
                    new PokemonType { Name = "AGUA"},
                    new PokemonType { Name = "FUEGO"},
                };
                foreach (var item in TypePokemon)
                {
                    context.PokemonTypes.Add(item);
                    context.SaveChanges();
                }
            }


            if (!context.Users.Any()) {
                context.Users.Add(new User { Username = "osduar", Password = "ky0MGWs71WJ/g1qG1VjHXZBKmXsOeQslnbHr2WoMLG0=" });
                context.SaveChanges();
            }

            return true;
        }
    }
}
